#include <Arduino.h>

#include "Trailer.h"

void CheckState(){
  switch (state){
  case 0:
  break;
  case 1:
  trailer_check_sensoren();
  break;
  case 2:

  break;
  case 3:
  trailer_get_message();
  trailer_check_steering_position();
  break;
  case 4:
  trailer_check_sensoren();
  trailer_get_message();
  trailer_check_steering_position();
  trailer_check_collision();
  break;
  // default:
  // break;
}
}

void setup(){

}

void loop (){
CheckState();
}
