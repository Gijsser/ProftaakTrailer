#ifndef _TRAILER_H
#define _TRAILER_H

#include <stdint.h>


enum State {
  0, //Alles uit
  1, //Allen geluid
  2, // Inparkeren
  3, // Volgen en meesturen
  4  // Volgen meesturen en ontijken
} state;


int trailer_get_state();
void trailer_set_state(int state);

void trailer_check_sensoren();
void trailer_set_steering_wheel_position(uint8_t position);
void trailer_check_steering_position();
void trailer_get_message();
void trailer_check_collision();
#endif
