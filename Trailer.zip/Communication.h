#ifndef _COMMUNICATION_H
#define _COMMUNICATION_H

void communication_send_sensor(int sensor, uint8_t distance);
int communication_check_available();
void communication_receive_message();
void communication_read_message(String message);
String ParseMessage(String unparsed, String &parsed); //Hoe deze opschrijven?
#endif
